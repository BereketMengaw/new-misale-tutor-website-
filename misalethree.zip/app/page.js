import Image from "next/image";
import Main from "../pages/main";
import Head from "next/head";

export default function Home() {
  return (
    <>
      <Main />
    </>
  );
}
