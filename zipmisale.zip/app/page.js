import Image from "next/image";
import Main from "../pages/main";

export default function Home() {
  return (
    <>
      <Main />
    </>
  );
}
